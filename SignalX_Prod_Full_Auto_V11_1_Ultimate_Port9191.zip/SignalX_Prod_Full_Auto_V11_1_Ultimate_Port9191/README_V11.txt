SignalX V11 — Auto-Demo + Charts — يعمل على 9191
1) فكّ الضغط
2) Start_SignalX.cmd
3) افتح http://localhost:9191/ — الصفحة تشغّل الديمو تلقائيًا وتعرض Price/EMA chart + RSI chart + جدول آخر 100 نقطة
إيقاف: Stop_SignalX.cmd — تنظيف موارد النسخة فقط: Clean_SignalX.cmd
ملحوظة: يستخدم Healthchecks لانتظار جاهزية الـBackend.
